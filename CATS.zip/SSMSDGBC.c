/*��°ͺղ���change*/
#include<stdio.h>
#include<math.h>
#include <conio.h>
#define z 30000
main()
{
	int x=0;
    int i,j,e,f,g,xz;
	int a[z];
	int t,u;
	printf("Input maximal even xz(if xz=0 kill new Process):");
    scanf("%d",&xz);
	if (xz==0) 
		system("tskill ssmsdgbc");
	//xz=20;
	for (g=6;g<=xz;g=g+2)             /*g>=6 even*/
	{
		u=0;
		x=0;
		for (i=2;i<=g;i++)
		{
			t=0;
		    for (j=2;j<=sqrt(i);j++)     /*look for prime number*/ 
				if (i%j==0)
				t=1;
			if (t==0)
			{
				x=x+1;
			    a[x]=i;
			}
		}
		for (e=1;e<=x;e++)
		{
			for (f=e;f<=x;f++)
				if (a[e]+a[f]==g)
				{
					u=1;
					printf("%d+%d=%d",a[e],a[f],g);
					printf("    successful\n");
				/*	break; */  /*in order to print every prime number for one time*/
				}
				/*if (u==1) break;*/  /*in order to print every prime number for one time*/
		
		}
				if (u==0)
				{
					printf("failure!!!");  /*in order to find a failure example*/
					break;
					printf(" The failure example is %d   ",g);
				}
	}
getch();
}
